<?PHP
$id = md5(rand(6000,PHP_INT_MAX));
?>
<?
include('geturl.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?echo $yourdomain;?> | ვებ ჰოსტინგი</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<meta name="description" content="უფასო ვებ ჰოსტინგი PHP მხარდაჭერით">
<link href="bootstrap.min.css" rel="stylesheet">
</head>
<body>
<a href="/index.php" class="btn btn-primary btn-block"><?echo $yourdomain;?></a>
<br><p><center><h2>უფასო ვებ ჰოსტინგი PHP მხარდაჭერით</h2></center></p><br>
<div class="container"><div class="row"><div class="col-md-6"><p>
<form action="http://cpanel.<?echo $yourdomain;?>/login.php" method="post" name="login" >
<p><input class="form-control" placeholder="მომხმარებელი" name="uname" type="text" alt="username" required></p>
<p><input class="form-control" placeholder="პაროლი" type="password" name="passwd" alt="password" required></p>
<p><input type="submit" name="Submit" value="შესვლა" class="btn btn-primary"/></p>
</form></p></div>
<div class="col-md-6"><p>
<form method=post action="http://order.<?echo $yourdomain;?>/register2.php">
<p><input class="form-control" placeholder="სახელწოდება" type=text name=username value="" pattern="[a-z0-9]{4,16}" maxlength="16" required></p>
<p><input class="form-control" placeholder="პაროლი" type=password name=password pattern=".{6,15}" maxlength="8" required></p>
<p><input class="form-control" placeholder="ელ. ფოსტა" type=text name=email pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$" value="" required></p>		
<p><input type=hidden name=id value="<?PHP echo $id; ?>">
<p><img class="btn btn-default" src="http://order.<? echo "$yourdomain" ;?>/image.php?id=<?PHP echo $id; ?>"> <small>ამოიცანით სურათზე ნაჩვენები სიმბოლოები</small></p>
<p><input class="form-control" placeholder="კოდი" type=text pattern=".{4,6}" name=number required></p>
<center><button type="submit" class="btn btn-primary">რეგისტრაცია</button></center>
</form></p></div>
    <div class="col-md-6">
	<br><p><img src="assets/images/website.jpg" alt="hosting"style="width:100%;"></p><br>
        </div>
    <div class="col-md-6">
     <br><h2>რა არის ეს?</h2>
            <p>ჩვენი სერვისი არის სისტემა, რომელიც საშუალებას გაძლევთ შექმნათ საკმაოდ მძლავრი და ფუნქციონალური ვებსაიტები პირდაპირ თქვენი მოწყობილობიდან სრულიად უფასოდ.</p>       
        <br></div><br>
    <br></div><br>
<br>
